1). My information
    
    Name : LieHuo Chen
    B Num : B00442344
    Email: lchen66@binghamton.edu


2). Instruction for running the program

    a. compile the program
        make 
    b. Clean before run again
        make clean
    c. Then the test.out is the runnable program. 
        Type : valgrind --leak-check=full ./test.out  

3). Test myself
    
    a. I have tested the program on cs.remote.binghamton.edu

    b. I have use the valgrind to check the memory leak, no leak.
